package com.example.borrowing_lending;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ViewBorrowedBooksActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_borrowed_books);
        // Implement functionality to display borrowed books
    }
}
